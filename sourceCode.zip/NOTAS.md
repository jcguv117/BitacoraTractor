##

### Instalar yarn para descargar las paqueterias de desarrollador

Ejecutar la siguiente instruccion si se usar la paqueteria yarn:
	
	    yarn

Se descargara la carpeta de "node_modules" necesario para el desarrollo en local.


El proyecto se incia con:

        yarn dev


Para compilar los archivos para produccion se usa la instruccion:

        yarn build

Se genera la carpeta "dist" con los archivos compilados.