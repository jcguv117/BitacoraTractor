
const AG_GRID_LOCALE_CUSTOM = {
    loadingOoo: 'Cargando...',
    loadingError: 'ERR',
    noRowsToShow: 'No hay movimientos que mostrar...',
    enabled: 'Habilitado',

    //pagination
    to: '-',
    of: 'de',
    page: 'Página',
    nextPage: 'Siguiente Página',
    lastPage: 'Ultima Página',
    firstPage: 'Primera Página',
    previousPage: 'Página Anterior',
  };
  

  export default AG_GRID_LOCALE_CUSTOM;